

public interface List {
	public Lst list = new Lst();
}
